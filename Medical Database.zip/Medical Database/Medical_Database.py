'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
#####
Ammaar Siddiqui
Medical Database
Version 1 .0
This is my Final Medical Database program.
The user makes an account. Once they have made an account they have the capability of checking for viruses and diseases based on symptom entry. They can also check their history of viruses, diseases, and symptoms
'''

import time#all imports
import os
import getpass

ALL_USERS=[]
ALL_DISEASES=[]
ALL_VIRUSES=[]

class Disease:
    def __init__(self, name, mini_age, gender, symptoms):#disease class
        self.name=name
        self.mini_age=mini_age
        self.gender=gender
        self.symptoms=symptoms

    def __str__():
        return(self.name.title())

class Virus:
    def __init__(self, name, symptoms):#virus class
        self.name=name
        self.symptoms=symptoms

    def __str__(self):
        return(self.name.title())

class User:
    def __init__(self, fname, lname, username, password, age, weight, height, gender):#user class
        self.fname=fname
        self.lname=lname
        self.username=username
        self.password=password
        self.age=age
        self.weight=weight
        self.height=height
        self.gender=gender

    def __str__(self):
        return(self.fname.title()+" "+self.lname.title())

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def write_func():#writes all of the diseases, users, and viruses from the files to the globals
    print("Welcome to the medical database. In this database you will be able to create an account, check for viruses, check for diseases, and keep track of all your symptoms, viruses, and diseases. (For best experience use in full screen)")
    global ALL_USERS
    global ALL_DISEASES
    global ALL_VIRUSES
    users=open("users.txt","r")
    for ln in users:
        u_info=ln.split("*")
        f=u_info[0]
        l=u_info[1]
        u=u_info[2]
        p=u_info[3]
        a=u_info[4]
        w=u_info[5]
        h=u_info[6]
        g=u_info[7]
        g=g.replace("\n","")
        ALL_USERS.append(User(f,l,u,p,int(a),int(w),int(h),g))
    users.close()
    viruses=open("viruses.txt","r")
    for ln in viruses:
        v_info=ln.split("**")
        n=v_info[0]
        s=v_info[1]
        s_list=s.split("*")
        s_list[-1] = s_list[-1].replace("\n","")
        ALL_VIRUSES.append(Virus(n,s_list))
    viruses.close()
    diseases=open("diseases.txt","r")
    for ln in diseases:
        d_info=ln.split("**")
        n=d_info[0]
        a=d_info[1]
        g=d_info[2]
        s=d_info[3]
        s_list=s.split("*")
        s_list[-1] = s_list[-1].replace("\n","")
        ALL_DISEASES.append(Disease(n,int(a),g,s_list))
    diseases.close()
    main_menu()

def main_menu():#main menu function
    print("1. User Login")
    print("2. Create Account")
    print("3. See All Viruses and Diseases")
    print("4. Quit")
    choice=input("Please pick an option: ")
    if choice=="1":
        clear_screen()
        login()
    elif choice=="2":
        clear_screen()
        username_func()
    elif choice=="3":
        clear_screen()
        see_database()
    elif choice=="4":
        quit()
    else:
        print("Invalid Option")
        time.sleep(2)
        clear_screen()
        main_menu()

def user_menu(current):#different menu once they login
    print("1. Check for Viruses")
    print("2. Check for Disease")
    print("3. See History")
    print("4. Logout")
    choice=input("Please pick an option: ")
    if choice=="1":
        clear_screen()
        symptom1_func(current)
    elif choice=="2":
        clear_screen()
        symptom1_d(current)
    elif choice=="3":
        clear_screen()
        history_func(current)
    elif choice=="4":
        clear_screen()
        main_menu()
    else:
        print("Invalid Option")
        time.sleep(2)
        clear_screen()
        user_menu(current)

def symptom1_func(current):#aks sfor first symptom
    symptoms=[]
    for virus in ALL_VIRUSES:
        for symptom in virus.symptoms:
            if symptom not in symptoms:
                symptoms.append(symptom)
    symptoms.sort()
    symptoms_join=""
    for symptom in range(len(symptoms)):
        if symptoms[symptom][0] == symptoms[symptom-1][0]:
            symptoms_join += f"{symptoms[symptom]}, "
        else:
            if symptoms_join != "":
                symptoms_join += f"\n{symptoms[symptom]}, "
            else:
                symptoms_join += f"{symptoms[symptom]}, "
    print(symptoms_join)#prints all the symptoms
    symptom1=input("Above is a comprehensive list of every symptom you could be having. Please enter the most extreme one you are having.(If you aren't having any, please enter none): ").lower()
    if symptom1=="none":
        print("There is no virus in my database that matches your symptom entry.")#if they enter none it tells them there is no matching virus
        time.sleep(2)
        clear_screen()
        user_menu(current)
    elif symptom1!="none":
        if symptom1 not in symptoms:
            print("Invalid option")
            time.sleep(2)#if they enter a synmptom that doesn't exist
            clear_screen()
            symptom1_func(current)
        else:
            symptom2_func(current,symptom1)#next symptom function
        
def symptom2_func(current,symptom1):#asks for second symptom
    symptoms=[]
    diagnosis=[]
    clear_screen()
    for virus in ALL_VIRUSES:
        if symptom1 in virus.symptoms:
            for symptom in virus.symptoms:
                if symptom !=symptom1:
                    if symptom not in symptoms:
                        symptoms.append(symptom)
    symptoms.sort()
    symptoms_join=""
    for symptom in range(len(symptoms)):
        if symptoms[symptom][0] == symptoms[symptom-1][0]:
            symptoms_join += f"{symptoms[symptom]}, "
        else:
            if symptoms_join != "":
                symptoms_join += f"\n{symptoms[symptom]}, "
            else:
                symptoms_join += f"{symptoms[symptom]}, "
    print(symptoms_join)#prints all remaining symptoms based on symptom1
    symptom2=input("Enter one of the above symptoms that you are having(If you aren't having any, please enter none): ").lower()
    if symptom2!="none":
        if symptom2 not in symptoms:
            print("Invalid Option")
            time.sleep(2)#checks if symptom exists
            symptom2_func(current, symptom1)
        else:
            symptom3_func(current, symptom1, symptom2)#next symptom
    elif symptom2=="none":
        for virus in ALL_VIRUSES:
            if symptom1 in virus.symptoms:
                diagnosis.append(virus.name)
    clear_screen()
    for virus in diagnosis:
        print(virus.title())
    print("You are showing the symptoms of the above mentioned virus or viruses.")
    symptom_check=[]
    symptom_check.append(symptom1)#diagnosis tells them what vrisu their symptom matches with
    save_virus(current, diagnosis, symptom_check)

def symptom3_func(current, symptom1, symptom2):
    symptoms=[]
    diagnosis=[]
    clear_screen()
    for virus in ALL_VIRUSES:
        if symptom2 in virus.symptoms and symptom1 in virus.symptoms:
            for symptom in virus.symptoms:
                if symptom !=symptom1 and symptom !=symptom2:
                    if symptom not in symptoms:
                        symptoms.append(symptom)
    symptoms.sort()
    symptoms_join=""
    for symptom in range(len(symptoms)):
        if symptoms[symptom][0] == symptoms[symptom-1][0]:
            symptoms_join += f"{symptoms[symptom]}, "
        else:
            if symptoms_join != "":
                symptoms_join += f"\n{symptoms[symptom]}, "
            else:
                symptoms_join += f"{symptoms[symptom]}, "
    print(symptoms_join)#prints all remaining symptoms
    symptom3=input("Enter one of the above symptoms that you are having(If you aren't having any, please enter none): ").lower()
    if symptom3!="none":
        if symptom3 not in symptoms:
            print("Invalid Options")
            time.sleep(2)#checks if symptom exists
            symptom3_func(current, symptom1, symptom2)
        else:
            clear_screen()
            diagnosis_func(current, symptom1, symptom2, symptom3)#diagnosis function
    elif symptom3=="none":
        for virus in ALL_VIRUSES:
            if symptom2 in virus.symptoms and symptom1 in virus.symptoms:
                diagnosis.append(virus.name)
    clear_screen()
    for virus in diagnosis:
        print(virus.title())#diagnosis tells them what virus their symptoms match with
    print("You are showing the symptoms of the above mentioned virus or viruses")
    symptom_check=[]
    symptom_check.append(symptom1)
    symptom_check.append(symptom2)
    save_virus(current, diagnosis, symptom_check)

def diagnosis_func(current, symptom1, symptom2, symptom3):#diagnosis function
    diagnosis=[]
    for virus in ALL_VIRUSES:
        if symptom1 in virus.symptoms and symptom2 in virus.symptoms and symptom3 in virus.symptoms:
            diagnosis.append(virus.name)
    clear_screen()
    for virus in diagnosis:
        print(virus.title())#prints virus that matches all three symptoms
    print("You are showing the symptoms of the above mentioned virus or viruses")
    symptom_check=[]
    symptom_check.append(symptom1)
    symptom_check.append(symptom2)
    symptom_check.append(symptom3)
    save_virus(current, diagnosis, symptom_check)

def save_virus(current, diagnosis, symptom_check):#saves virus to file for history function
    ts = time.gmtime()
    time_formatted=(time.strftime("%m-%d-%Y", ts))#finds date
    history=open("virus_history.txt","a")
    for virus in diagnosis:
        history.write(current.username+"**"+virus+"**")
        for symptom in symptom_check:
            history.write(symptom+"*")
        history.write("*"+time_formatted+"\n")#writes username, symptoms, and virus
    history.close()
    user_menu(current)
    
def symptom1_d(current):
    symptoms=[]
    clear_screen()
    for disease in ALL_DISEASES:
        for symptom in disease.symptoms:
            if symptom not in symptoms:
                symptoms.append(symptom)
    symptoms.sort()
    symptoms_join=""
    for symptom in range(len(symptoms)):
        if symptoms[symptom][0] == symptoms[symptom-1][0]:
            symptoms_join += f"{symptoms[symptom]}, "
        else:
            if symptoms_join != "":
                symptoms_join += f"\n{symptoms[symptom]}, "
            else:
                symptoms_join += f"{symptoms[symptom]}, "
    print(symptoms_join)#prints all symptoms
    symptom1=input("Above is a comprehensive list of every symptom you could be having. Please enter the most extreme one you are having.(If you aren't having any, please enter none): ").lower()
    if symptom1=="none":
        print("There is no disease in my database that matches your symptom entry.")
        time.sleep(2)
        clear_screen()
        user_menu(current)
    elif symptom1!="none":
        if symptom1 not in symptoms:
            print("Invalid option")
            time.sleep(2)#checks if symptom exists
            symptom1_d(current)
        else:
            symptom2_d(current,symptom1)#next symptom

def symptom2_d(current,symptom1):
    symptoms=[]
    diagnosis=[]
    clear_screen()
    for disease in ALL_DISEASES:
        if symptom1 in disease.symptoms:
            for symptom in disease.symptoms:
                if symptom !=symptom1:
                    if symptom not in symptoms:
                        symptoms.append(symptom)
    symptoms.sort()
    symptoms_join=""
    for symptom in range(len(symptoms)):
        if symptoms[symptom][0] == symptoms[symptom-1][0]:
            symptoms_join += f"{symptoms[symptom]}, "
        else:
            if symptoms_join != "":
                symptoms_join += f"\n{symptoms[symptom]}, "
            else:
                symptoms_join += f"{symptoms[symptom]}, "
    print(symptoms_join)#prints all symptoms
    symptom2=input("Enter one of the above symptoms that you are having(If you aren't having any, please enter none): ").lower()
    if symptom2!="none":
        if symptom2 not in symptoms:
            print("Invalid Option")
            time.sleep(2)#checks if symptom exists
            symptom2_d(current, symptom1)
        else:
            symptom3_d(current, symptom1, symptom2)#next symptom
    elif symptom2=="none":
        for disease in ALL_DISEASES:
            if symptom1 in disease.symptoms:
                diagnosis.append(disease.name)
    clear_screen()
    symptom_check=[]
    symptom_check.append(symptom1)
    check(current,diagnosis,symptom_check)


def symptom3_d(current,symptom1,symptom2):
    symptoms=[]
    diagnosis=[]
    clear_screen()
    for disease in ALL_DISEASES:
        if symptom2 in disease.symptoms and symptom1 in disease.symptoms:
            for symptom in disease.symptoms:
                if symptom !=symptom1 and symptom !=symptom2:
                    if symptom not in symptoms:
                        symptoms.append(symptom)
    symptoms.sort()
    symptoms_join=""
    for symptom in range(len(symptoms)):
        if symptoms[symptom][0] == symptoms[symptom-1][0]:
            symptoms_join += f"{symptoms[symptom]}, "
        else:
            if symptoms_join != "":
                symptoms_join += f"\n{symptoms[symptom]}, "
            else:
                symptoms_join += f"{symptoms[symptom]}, "
    print(symptoms_join)#prinst all symptoms
    symptom3=input("Enter one of the above symptoms that you are having(If you aren't having any, please enter none): ").lower()
    if symptom3!="none":
        if symptom3 not in symptoms:
            print("Invalid Options")
            time.sleep(2)#checks if symptom exists
            symptom3_d(current, symptom1, symptom2)
        else:
            clear_screen()
            diagnosis_d(current, symptom1, symptom2, symptom3)#diagnosis function
    elif symptom3=="none":
        for disease in ALL_DISEASES:
            if symptom2 in disease.symptoms and symptom1 in disease.symptoms:
                diagnosis.append(disease.name)
    clear_screen()
    symptom_check=[]
    symptom_check.append(symptom1)
    symptom_check.append(symptom2)
    check(current,diagnosis,symptom_check)

def diagnosis_d(current, symptom1, symptom2, symptom3):#diagnosis function
    diagnosis=[]
    for disease in ALL_DISEASES:
        if symptom1 in disease.symptoms and symptom2 in disease.symptoms and symptom3 in disease.symptoms:
            diagnosis.append(disease.name)
    clear_screen()
    symptom_check=[]
    symptom_check.append(symptom1)
    symptom_check.append(symptom2)
    symptom_check.append(symptom3)
    check(current,diagnosis,symptom_check)#check function  

def check(current,diagnosis,symptom_check):
    age=False
    gender=False
    BMI=False
    for disease1 in diagnosis:
        risk_factors=0
        for disease in ALL_DISEASES:
            if disease.name==disease1:
                if disease.mini_age<=current.age:
                    risk_factors+=1
                    age=True
                if current.gender==disease.gender:
                    risk_factors+=1
                    gender=True
                if ((current.weight/current.height**2)*703)>=25:
                    risk_factors+=1
                    BMI=True
        print("You are showing the symptoms of "+disease1)
        print("You have "+str(risk_factors)+" risk factor(s) of this disease")
        if age==True or gender==True or BMI==True:
            print("Your risk factors are listed below")
        if age==True:
            print("Age")
        if gender==True:
            print("Gender")
        if BMI==True:
            print("BMI")
    print("Each risk factor increases your chances of having that disease.")#determines risk factors
    ts = time.gmtime()
    time_formatted=(time.strftime("%m-%d-%Y", ts))
    history=open("disease_history.txt","a")
    for disease in diagnosis:
        history.write(current.username+"**"+disease+"**")
        for symptom in symptom_check:
            history.write(symptom+"*")
        history.write("*"+time_formatted+"\n")
    history.close()#write username, symptoms, and disease to file for history
    user_menu(current)
    
def history_func(current):
    print("1. See Virus History")
    print("2. See Disease History")
    print("3. Back to Menu")
    choice=input("Please pick an option: ")
    if choice=="1":
        check=0
        clear_screen()
        v_history=open("virus_history.txt","r")
        for ln in v_history:
            v_info=ln.split("**")
            if v_info[0]==current.username:
                check=check+1
                v_info[3]=v_info[3].replace("\n","")
                print("On "+v_info[3]+" you entered the following symptom(s).")
                v_symptoms=v_info[2].split("*")
                for symptom in v_symptoms:
                    print(symptom)
                print("These symptoms or symptom matched the virus "+v_info[1].title())
        if check==0:
            print("You have no virus history.")
            time.sleep(2)
            clear_screen()
        history_func(current)#gets all virus history
    elif choice=="2":
        check=0
        clear_screen()
        d_history=open("disease_history.txt","r")
        for ln in d_history:
            d_info=ln.split("**")
            if d_info[0]==current.username:
                check=check+1
                d_info[3]=d_info[3].replace("\n","")
                print("On "+d_info[3]+" you entered the following symptom(s).")
                d_symptoms=d_info[2].split("*")
                for symptom in d_symptoms:
                    print(symptom)
                print("These symptoms or symptom matched the disease "+d_info[1])
        if check==0:
            print("You have no disease history.")
            time.sleep(2)
            clear_screen()
        history_func(current)#gets all disease hsitory
    elif choice=="3":
        clear_screen()
        user_menu(current)#goes back to menu
    else:
        print("Invalid option")
        time.sleep(2)
        clear_screen()
        history_func(current)#catch all else
                
def login():
    logintf=True
    username=input("Username: ")
    password=getpass.getpass()
    for user in ALL_USERS:
        if username==user.username and password==user.password:
            print("Logged In")
            logintf=True
            current=User(user.fname, user.lname, user.username, user.password, user.age, user.weight, user.height, user.gender)
            time.sleep(1)
            clear_screen()
            user_menu(current)#checks if login matches any of the logins
        else:
            logintf=False
    if logintf==False:
        print("Invalid Username and/or Password")#if it doesn't it tells them
        time.sleep(2)
        clear_screen()
        main_menu()    

def username_func():#asks for username and checks for duplicates
    usernames=[]
    for user in ALL_USERS:
        usernames.append(user.username)
    username=input("Username: ")
    if username in usernames:
        print("This username is already taken.")
        time.sleep(2)
        clear_screen()
        username_func()
    else:
        info_func(username)

def info_func(username):#asks for password, first name, and last name
    password=input("Password: ")
    fname=input("First Name: ")
    lname=input("Last Name: ")
    clear_screen()
    size_func(username,password,fname,lname)

def size_func(username,password,fname,lname): #asks for age, weight, and height. Also checks if they are numbers and in range
    try:
        age=int(input("Age: "))
        weight=int(float(input("Weight(in lbs): ")))
        height=int(float(input("Height(in inches): ")))
    except (ValueError):
        print("Age, weight, and height must be numbers")
        time.sleep(2)
        clear_screen()
        size_func(username,password,fname,lname)
    if age<0 or age>122 or weight<=0 or weight>1400 or height<12 or height>99:
        print("Age, height, or weight is out of range")
        time.sleep(2)
        clear_screen()
        size_func(username, password, fname, lname)
    gender_func(username,password,fname,lname,age,height,weight)

def gender_func(username,password,fname,lname,age,height,weight):#asks for gender and checks if it is male or female
    gender=input("What is your gender(male/female): ")
    if gender!="male" and gender!="female":
        print("Gender must be male or female.")
        time.sleep(2)
        clear_screen()
        gender_func(username,password,fname,lname,age,height,weight)
    else:
        clear_screen()
        create_account(username,password,fname,lname,age,height,weight,gender)

def create_account(username,password,fname,lname,age,height,weight,gender):
    ALL_USERS.append(User(fname, lname, username, password, age, weight, height, gender))
    users=open("users.txt","a")
    users.write(fname+"*"+lname+"*"+username+"*"+password+"*"+str(age)+"*"+str(weight)+"*"+str(height)+"*"+gender+"\n")
    users.close()
    print("Account successfully created.")
    time.sleep(2)
    clear_screen()
    main_menu()#creates account writing to the file and global

def see_database():#menu for looking at the whole database
    print("1. See All Viruses")
    print("2. See all Diseases")
    print("3. Back to Menu")
    choice=input("Please pick an option: ")
    if choice=="1":
        clear_screen()
        see_viruses()
    elif choice=="2":
        clear_screen()
        see_diseases()
    elif choice=="3":
        clear_screen()
        main_menu()
    else:
        print("Invalid option")
        time.sleep(2)
        clear_screen()
        see_database()

def see_viruses():
    for virus in ALL_VIRUSES:
        print(virus.name.title())
    see_database()#prints all viruses

def see_diseases():
    for disease in ALL_DISEASES:
        print(disease.name.title())
    see_database()#prints all diseases
        
write_func()#runs write func starting whole program












